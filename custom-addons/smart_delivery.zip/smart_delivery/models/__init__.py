# -*- coding: utf-8 -*-

from . import delivery_order
from . import livreur
from . import livreur_document
from . import livreur_wizard
from . import enterprise
from . import enterprise_document
from . import delivery_condition
from . import sector_rule
from . import billing
from . import account_move
from . import delivery_route
from . import api_log
from . import res_users
from . import res_partner
from . import ir_http

