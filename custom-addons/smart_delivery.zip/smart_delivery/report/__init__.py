# -*- coding: utf-8 -*-
# Report templates are defined in XML, no Python files needed

